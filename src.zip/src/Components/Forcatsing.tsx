// import * as React from "react";
// import "../../src/forcast.css" 
// import { Dayjs } from 'dayjs'; 
// import { useContext, useEffect, useRef, useState, createContext } from "react";
// import { SiCodeforces } from "react-icons/si"; 
// import XLSX from 'xlsx/dist/xlsx.full.min.js';
// import Papa from  "papaparse"
// import {data, columns, prepareData} from './../data'
// import {EditableCellProps, EditableContext, Item, EditableRow, EditableCell} from './EditableCellForecast' 
// import {
//   LineOutlined, 
//   PlusOutlined, 
//   MinusOutlined, 
//   ArrowUpOutlined, 
//   ArrowDownOutlined, 
//   DeleteOutlined, 
//   EditOutlined, 
//   ShrinkOutlined, 
//   LeftOutlined, 
//   RightOutlined
// } from "@ant-design/icons";
// import {   
//   Modal,  
//   DatePicker,  
//   Radio, 
//   Select, 
//   Upload, 
//   message,
//   InputRef, 
//   TableProps,
//   Pagination,
//   Button, 
//   Form, 
//   Input, 
//   Popover, 
//   Slider, 
//   Table
// } from "antd";
// import { PopupModal, WhatIfParameterType, BlankForecastObject, ARRAY_RADIO } from "./PopUpForecast" 

// const { RangePicker } = DatePicker;
// interface RevenueData {
//   ID: any;
//   key: string;
//   CompanyName: string;
//   Revenue2022: string;
//   Revenue2023: string;
//   Revenue2024: string;
//   forecasts?: Array<{ key: string; forecastValue: number }>;
// }

// interface ForecastingProps {
//   host: any;
//   options1: any;
//   dataView: any;
//   exportDataCb: any;
//   formattingSettings: any;
//   target: any;
// }
// /*
// const Forcasting: React.FC<ForecastingProps> = ({ host, options1,  exportDataCb, dataView, formattingSettings,target }) => {
//   const [dataSource, setDataSource] = useState<RevenueData[]>([]);
//   const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
//   const [forecastTitle, setForecastTitle] = useState<string>("");
//   const [forecastRange, setForecastRange] = useState<[Dayjs, Dayjs] | null>(null);
//   const [forecastType, setForecastType] = useState<string>("blank");
//   const [revenueData, setRevenueData] = useState<RevenueData[]>([]);
//   const [selectedColumn, setSelectedColumn] = useState<string>("");
//   const [addedColumns, setAddedColumns] = useState<any[]>([]);  
//   const[importdata ,setImportdata] = useState<RevenueData[]>([]);

//   const forecastMultipleYears = (year2023: string, year2024: string, years: number): number[] => {
//     const forecasts: number[] = [];
//     const value2023 = parseFloat(year2023);
//     const value2024 = parseFloat(year2024);
//     if (isNaN(value2023) || isNaN(value2024) || value2023 === 0) {
//       return Array(years).fill(0);
//     }
//     const growthRate = (value2024 - value2023) / value2023;
//     forecasts.push(parseFloat((value2024 * (1 + growthRate)).toFixed(2)));
//     for (let i = 1; i < years; i++) {
//       const nextForecast = parseFloat((forecasts[i - 1] * (1 + growthRate)).toFixed(2));
//       forecasts.push(nextForecast);
//     }
//     return forecasts;
//   };
//   useEffect(() => {
//     fetch("http://localhost:8000/revenue")
//       .then(response => {
//         if (!response.ok) {
//           throw new Error("Network response was not ok");
//         }
//         return response.json();
//       })
//       .then((data: RevenueData[]) => {
//         setRevenueData(data);
//         setDataSource(data);
//       })
//       .catch(error => {
//         console.error("Error fetching data:", error);
//       });
//   }, []);

//   const handleModalOk = () => {
//     const years = forecastRange ? forecastRange[1].year() - forecastRange[0].year() + 1 : 0;
//     const modifyData = revenueData.map((item) => {
//       let forecasts;
//       if (forecastType === "future") {
//         forecasts = forecastMultipleYears(item.Revenue2023, item.Revenue2024, years);
//       } else if (forecastType === "existing") {
//         forecasts = item.forecasts ? item.forecasts.map(f => f.forecastValue) : Array(years).fill(0);
//       } else {
//         forecasts = Array(years).fill(0);
//       }
//       return {
//         ...item,
//         [`Forcast_${selectedColumn}`]: item[selectedColumn],
//         forecasts: forecasts.map((value, i) => ({
//           key: `${item[selectedColumn]}-${i}`,
//           forecastValue: value,
//         })),
//       }
//     })
//     console.log(modifyData, "modifydata")

//     setIsModalVisible(false);
//     if (forecastType == "existing" || forecastType == "existing" ) {
//       console.log("Hi in IF")
//       setDataSource(pre => {
//         const a = pre.map((d) => {
//           d[`Forcast_${selectedColumn}`] = d[selectedColumn]
//         })
//         return pre
//       })
//       console.log("Data change completed")
//        if (selectedColumn) {
//         setAddedColumns(prev => [...prev, `Forcast_${selectedColumn}`]); 
//       }
//     } else {
//       console.log("else")
//       setAddedColumns([])
//       setColumns([])
//       setDataSource(modifyData)
//     }
//     //setAddedColumns([])
//     console.log("performChanges calling")
//     performChanges()
//     console.log("performChanges calling completed")
//     // zzzzresetForm()
//   };

//   const handleModalCancel = () => {
//     // resetForm();
//     setIsModalVisible(false);
//   };
//   const handleForecastChange = (value: number, recordKey: string, index: number) => {
//     setDataSource(prevData =>
//       prevData.map(item => {
//         if (item.key === recordKey) {
//           const newForecasts = item.forecasts?.map((forecast, i) => {
//             if (i === index) {
//               return { ...forecast, forecastValue: value };
//             }
//             return forecast;
//           });
//           return { ...item, forecasts: newForecasts };
//         }
//         return item;
//       })
//     );
//   };
//   const handleDynamicColumnChange = (value: string, recordKey: string) => {
//     console.log(value, recordKey)
//     setDataSource(prevData =>
//       prevData.map(item => {
//         if (item.ID == recordKey) {
//           console.log(item)
//           return { ...item, [`Forcast_${selectedColumn}`]: value };
//         }
//         return item;
//       })
//     );
//   };
//   const handleExistingColumnChange = (value: string, recordKey: string, column: string) => {
//     console.log(value)
//     setDataSource(prevData =>
//       prevData.map(item => {
//         if (item.key === recordKey) {
//           return { ...item, [column]: value };
//         }
//         return item;
//       })
//     );
//   };
//   const handleDeleteColumn = (columnKey: string) => {
//       // Remove from addedColumns
//       setAddedColumns(prev => prev.filter(column => column !== columnKey));
      
//       // Remove from columns
//       setColumns(prevColumns => prevColumns.filter(column => column.dataIndex !== columnKey));
//   };

//   const defaultColumns = [
//     {
//       title: (
//         <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//           Company Name
//         </div>
//       ),
//       dataIndex: "CompanyName",
//       render: (text: any, record: RevenueData) => (
//         <input
//           className="inputcolor"
//           value={text}
//           onChange={(e) => handleExistingColumnChange(e.target.value, record.key = record.ID, 'CompanyName')}
//           style={{ width: '100%', border: 'none', padding: '0px' }}
//         />
//       ),
//       width: "30%",
//     },
//     {
//       title: (
//         <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//           Revenue2022
//         </div>
//       ),
//       dataIndex: "Revenue2022",
//       render: (text: any, record: RevenueData) => (
//         <input
//           className="inputcolor"
//           value={text}
//           onChange={(e) => handleExistingColumnChange(e.target.value, record.key = record.ID, 'Revenue2022')}
//           style={{ width: '100%', border: 'none', padding: '0px' }}
//         />
//       ),
//       width: "25%",
//     },
//     {
//       title: (
//         <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//           Revenue2023
//         </div>
//       ),
//       dataIndex: "Revenue2023",
//       render: (text: any, record: RevenueData) => (
//         <input
//           className="inputcolor"
//           value={text}
//           onChange={(e) => handleExistingColumnChange(e.target.value, record.key = record.ID, 'Revenue2023')}
//           style={{ width: '100%', border: 'none', padding: '0px' }}
//         />
//       ),
//       width: "25%",
//     },
//     {
//       title: (
//         <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//           Revenue2024
//         </div>
//       ),
//       dataIndex: "Revenue2024",
//       render: (text: any, record: RevenueData) => (
//         <input
//           value={text}
//           className="inputcolor"
//           onChange={(e) => handleExistingColumnChange(e.target.value, record.key = record.ID, 'Revenue2024')}
//           style={{ width: '100%', border: 'none', padding: '0px' }}
//         />
//       ),
//       width: "25%",
//     },
//   ];

//   //columns related code

//   const [columns, setColumns] = useState(defaultColumns)
//   const performChanges = () => {
//     console.log(dataSource, "data in perform change");
    
//     // Existing dynamic columns
//     let dynamicColumns = addedColumns.map(column => ({
//       title: (
//         <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//           {column}
//           <DeleteOutlined 
//             onClick={() => handleDeleteColumn(column)} 
//             style={{ color: "white", cursor: "pointer" }} 
//           />
//         </div>
//       ),
//       dataIndex: column,
//       render: (text: any, record: RevenueData) => (
//         <input
//           className="inputcolor"
//           value={record[column] || ''}
//           onChange={(e) => {
//             console.log(e.target.value, "Existing");
//             handleDynamicColumnChange(e.target.value, record.ID);
//           }}
//           style={{ width: '100%', border: 'none', padding: '0px', color: 'red' }}
//         />
//       ),
//       width: "25%",
//     }));

//     // Forecast columns
//     let forecastColumns = [];
//     forecastColumns = forecastRange ?
//       Array.from({ length: forecastRange[1].year() - forecastRange[0].year() + 1 }, (_, index) => ({
//         title: (
//           <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//             {`${forecastTitle} ${forecastRange[0].year() + index}`}
//             <DeleteOutlined 
//               onClick={() => handleDeleteColumn(`forecast${index}`)}  // Correctly passing column identifier
//               style={{ color: "white", cursor: "pointer" }} 
//             />
//           </div>
//         ),
//         dataIndex: `forecast${index}`,
//         width: "25%",
//         render: (text: any, record: RevenueData) => {
//           record.key = record.ID;
//           const forecastValue = record.forecasts?.[index]?.forecastValue ?? "";
//           return forecastType === "blank" ? (
//             <input
//               id={`forecast-${record.key}-${index}`} // Unique ID for each input
//               value={forecastValue}
//               className="inputcolor"
//               onChange={(e) => {
//                 const newForecastValue = e.target.value ? parseFloat(e.target.value) : 0;
//                 handleForecastChange(newForecastValue, record.key, index);
//               }}
//               style={{ width: '100px', border: 'none', padding: '0px' }}
//             />
//           ) : (
//             <span>{forecastValue}</span>
//           );
//         },
//       })) : [];

//     console.log("seeting columns");
//     if (forecastType === "existing") {
//       setColumns([...defaultColumns, ...dynamicColumns, ...forecastColumns]);
//       console.log(dynamicColumns, "dynamicColumns");
//     }
//     if (forecastType === "future") {
//       setColumns([...defaultColumns, ...forecastColumns]);
//       console.log(forecastColumns, "forecastColumns");
//     }
//     if (forecastType === "blank") {
//       setColumns([...defaultColumns, ...forecastColumns]);
//       console.log(forecastColumns, "blank");
//       console.log(addedColumns, "addedColumns");
//     }

//     console.log("seeting columns completed");
//     setForecastTitle("");
//     setForecastRange(null);
//     // setSelectedColumn("");
//   };
 
//   useEffect(() => {
//     if(forecastType=="existing") performChanges();
//   }, [ addedColumns, addedColumns]);
//   useEffect(() => {
//     console.log("columns", columns)
//     console.log("data in columns", dataSource)
//   }, [columns])
 
//   const options = defaultColumns.map((d: any) => ({
//     label: d.dataIndex,
//     value: d.dataIndex,
//   }));
//   const resetForm = () => {
//     // debugger
//     setForecastTitle('');
//     setForecastRange(null);
//     //  debugger
//   }
//   const convertToCSV = (array) => {
//     if (!array || array.length === 0) return ''; // Handle empty data cases

//     const keys = Object.keys(array[0]); // Extract keys (headers) from the first object
//     const csvRows = [];

//     // Create the header row
//     csvRows.push(keys.join(','));

//     // Map over each row and create a CSV string for each row
//     array.forEach((row) => {
//       const values = keys.map((key) => {
//         const value = row[key];
//         return `"${value}"`; // Wrap each value in quotes to handle commas
//       });
//       csvRows.push(values.join(','));
//     });

//     return csvRows.join('\n'); // Join all rows by a newline character
//   };

//   // Function to handle download process in Power BI custom visual using exportDataCb
//   const handleDownload = (dataSource, host, exportDataCb) => {
//     console.log("Download initiated");

//     // Check if dataSource exists and is not empty
//     if (!dataSource || dataSource.length === 0) {
//       console.error("Data source is empty. Nothing to download.");
//       return;
//     }

//     // Prepare data to be downloaded
//     const dataToDownload = dataSource.map((row) => ({
//       ...row,
//     }));

//     console.log("Data to download:", dataToDownload);

//     // Convert data to CSV format
//     const fileContent = convertToCSV(dataToDownload);

//     // Verify if CSV content is correct
//     console.log("File content:", fileContent);

//     if (!fileContent) {
//       console.error("No content to download.");
//       return;
//     }

//     // Call exportDataCb to handle the CSV content
//     exportDataCb(fileContent, "csv file");

//     // Create a Blob from the CSV content for download via Power BI
//     const blob = new Blob([fileContent], { type: "text/csv;charset=UTF-8" });

//     console.log("Blob created:", blob);

//     // Power BI's IDownloadService to handle downloads
//     console.log("host", host);
//     const downloadService = host.downloadService; // Ensure `host` is passed as a prop from Power BI

//     console.log("downloadService available:", downloadService && typeof downloadService.downloadBlob === 'function');

//     if (downloadService && typeof downloadService.downloadBlob === 'function') {
//       // Use the service to download the CSV file
//       downloadService.downloadBlob(blob, "forecasting_data.csv");
//       console.log("Download triggered successfully");
//     } else {
//       console.error("Download service is not available.");
//     }
//   };


//   const handleFileUpload = (file: File) => {
//     const fileReader = new FileReader();
//     fileReader.onload = (e: any) => {
//       const fileType = file.name.split('.').pop()?.toLowerCase();

//       // Log the file type for verification
//       console.log("File Type:", fileType);

//       if (fileType === 'csv') {
//         // Parse CSV using PapaParse
//         console.log("Parsing CSV file...");
//         Papa.parse(e.target.result, {
//           header: true, // Use the first row as column headers
//           skipEmptyLines: true,
//           complete: (result: any) => {
//             console.log("Parsed CSV Data:", result.data); // Log the parsed CSV data
//             setDataSource(result.data);
//             message.success('CSV file uploaded successfully!');
//           },
//         });
//       } else if (fileType === 'xlsx' || fileType === 'xls') {
//         // Parse Excel using xlsx
//         console.log("Parsing Excel file...");
//         const binaryStr = e.target.result;
//         console.log("binaryStr",binaryStr)
//         const workbook = XLSX.read(binaryStr, { type: 'binary' });

//         console.log("Workbook:", workbook); // Log the workbook to inspect its structure

//         const sheetName = workbook.SheetNames[0];
//         const sheet = workbook.Sheets[sheetName];

//         console.log("Sheet Data:", sheet); // Log the sheet data

//         const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: '' });
//         console.log("Parsed Excel Data:", jsonData); // Log the parsed Excel data

        


//         const addIdToData = ( jsonData) => {
//           return  jsonData.map((row, index) => ({
//             ID: index + 1, // Add an id field starting from 1
//             ...row,        // Spread the existing row data
//           }));
//         };

//         const dataWithId = addIdToData(jsonData);  // Call the function to add IDs
//         console.log("Data with IDs:", dataWithId);
//        // setDataSource(jsonData as any);
//        setImportdata(dataWithId as any)
//         message.success('Excel file uploaded successfully!');
//       } else {
//         message.error('Unsupported file format. Please upload CSV or Excel.');
//       }
//     };

//     if (file.type === 'text/csv') {
//       console.log("Reading CSV file as text...");
//       fileReader.readAsText(file);
//     } else {
//       console.log("Reading Excel file as binary...");
//       fileReader.readAsBinaryString(file);
//     }

//     return false; // Prevent auto upload by Ant Design
//   };

//   console.log("importdtaa", importdata)
//   console.log("dataSource", dataSource)

//   return (
//     // <div>
//     //   <div style={{ display:'flex',justifyContent:'space-between', alignItems:'center'}}>   
//     //   <button onClick={() => setIsModalVisible(true)} className='forcast'>
//     //     Forecasting
//     //   </button>
//     //   <button className='forcast'onClick={exportToCSV} >
//     //     Export
//     //   </button>
//     //   {forecastType == "blank" ? (
//     //   <button className='forcast' >
//     //     Import
//     //   </button> ) :( <>  </>) }
//     //   </div>
//     //   <Modal
//     //     title="Select Forecast Options"
//     //     visible={isModalVisible}
//     //     onOk={handleModalOk}
//     //     onCancel={handleModalCancel}
//     //   >
//     //     <Form layout="vertical">
//     //       {forecastType === "existing" ? (
//     //         <div>
//     //           <label>Select Existing Columns</label>
//     //           <Select
//     //             value={selectedColumn}
//     //             onChange={(value) => setSelectedColumn(value)}
//     //             style={{ width: "100%" }}
//     //             options={options}
//     //           />
//     //         </div>
//     //       ) : (
//     //         <>
//     //           <Form.Item label="Forecast Title" required>
//     //             <Input
             
//     //               value={forecastTitle}
//     //               onChange={(e) => setForecastTitle(e.target.value)}
//     //               placeholder="Enter forecast title"
//     //             />
//     //           </Form.Item>
//     //           <Form.Item label="Select Date Range" required>
//     //             <RangePicker
               
//     //               value={forecastRange}
//     //               onChange={setForecastRange}
//     //               format="YYYY-MM-DD"
//     //             />
//     //           </Form.Item>
//     //         </>
//     //       )}
//     //       <Form.Item label="Forecast Type" required>
//     //         <Radio.Group value={forecastType} onChange={(e) => setForecastType(e.target.value)}>
//     //           <Radio value="blank">Blank Forecast</Radio>
//     //           <Radio value="future">Future Forecast</Radio>
//     //           <Radio value="existing">Existing Forecast</Radio>
//     //         </Radio.Group>
//     //       </Form.Item>
//     //     </Form>
//     //   </Modal>
//     //   <Table
//     //     bordered
//     //     className="custom-table"
//     //     dataSource={dataSource}
//     //     columns={columns}
//     //   />
//     // </div>
//     <div>
//       <div style={{ display:'flex',gap:'8px', alignItems:'center', margin:'10px 10px'}}>   
//       <Button onClick={() => setIsModalVisible(true)} className='button-style'>
//         Forecasting
//       </Button> 
//       <Button className='button-style' onClick={() => handleDownload(dataSource, host, exportDataCb)}  >
//         Export
//       </Button> 
//       </div>
//       <Modal
//         title="Select Forecast Options"
//         visible={isModalVisible}
//         onOk={handleModalOk}
//         onCancel={handleModalCancel}
//       >
//         <Form layout="vertical">
//           {forecastType === "existing" ? (
//             <div>
//             <div>
//               <label>Select Existing Columns</label>
//               <Select
//                 value={selectedColumn}
//                 onChange={(value) => setSelectedColumn(value)}
//                 style={{ width: "100%" }}
//                 options={options}
//               />
//             </div>
//             <div>
//               <Upload
//                  beforeUpload={handleFileUpload} // Handle file upload before submitting
//                  accept=".csv,.xlsx,.xls" // Accept only CSV and Excel files
//                  showUploadList={false} // Hide upload list
//                >
//                  <Button className="button-style">Import</Button>
//                </Upload>
//             </div>
//             </div>
//           ) : (
//             <>
//               <Form.Item label="Forecast Title" required>
//                 <Input
             
//                   value={forecastTitle}
//                   onChange={(e) => setForecastTitle(e.target.value)}
//                   placeholder="Enter forecast title"
//                 />
//               </Form.Item>
//               <Form.Item label="Select Date Range" required>
//                 <RangePicker
               
//                   value={forecastRange}
//                   onChange={setForecastRange}
//                   format="YYYY-MM-DD"
//                 />
//               </Form.Item>
//             </>
//           )}
//           <Form.Item label="Forecast Type" required>
//             <Radio.Group value={forecastType} onChange={(e) => setForecastType(e.target.value)}>
//               <Radio value="blank">Blank Forecast</Radio>
//               <Radio value="future">Future Forecast</Radio>
//               <Radio value="existing">Existing Forecast</Radio>
//             </Radio.Group>
//           </Form.Item>
//         </Form>
//       </Modal>
      
//       <Table
//       bordered
//       className="custom-table hide-scrollbar"
//       // dataSource={dataSource}
//       dataSource={importdata && importdata.length > 0 ? importdata : dataSource}
//       columns={columns}
//       pagination={{
//         pageSize: 20, // Adjust the page size as needed
//         total: dataSource.length, // Total number of data items
//         position: ["bottomRight"], // Pagination at the bottom right
//         showTotal: (total, range) => `${range[0]}-${range[1]} of ${total}`, // Showing range of displayed items
//         itemRender: (_, type, originalElement) =>
//       {
//           if (type === "prev") {
//             return <LeftOutlined />;  // Custom icon for 'Previous' button
//           }
//           if (type === "next") {
//             return <RightOutlined />; // Custom icon for 'Next' button
//           }
//           return originalElement; // Default pagination elements
//         },
//       }}
//       scroll={{x: '100%', y: 400 }}  // Enable scroll for the body
//     />
//     </div>
//   );
// };
// */

// type ColumnTypes = Exclude<TableProps["columns"], undefined>;

// const Forcasting : React.FC<ForecastingProps> = ({ 
//   host, 
//   options1,  
//   exportDataCb, 
//   dataView, 
//   formattingSettings,
//   target
// }) => {
//   const [columns, setColumns] = useState<any[]>([]);
//   const [fetchedDataSource, setFetchedDataSource] = useState<any[]>([]);
//   const [modifiedDataSource, setModifiedDataSource] = useState<any[]>([]);
//   //popup related
//   const [isPopUpVisible, setPopUpVisible] = useState(false);
//   const [clickedColumnName, setClickedColumnName] = useState<string>("");
//   const [modalObject, setModalObject] = useState<any>({}) 

//   const components = {
//     body: {
//       row: EditableRow,
//       cell: EditableCell,
//     },
//   }; 

//   const mappedColumns = columns.map((col) => ({
//       ...col,
//       onCell: (record) => ({
//           record,
//           editable: col.editable,
//           dataIndex: col.dataIndex,
//           title: col.title,
//           handleSave: (updatedRecord, updatedChildren) => {
//               console.log(updatedRecord, updatedChildren);
//               // Function to update the modifiedDataSource with the new value
//               // const updateDataSourceWithParent = (dataSource, updatedRec) => {
//               //     return dataSource.map((item) => {
//               //         if (item["ID"] === updatedRec["ID"]) {
//               //           console.log("IF")
//               //             // If the record is found, update it directly with new children
//               //             return {
//               //                 ...updatedRec,
//               //                 children: updatedChildren,
//               //             };
//               //         } else if (item.children && item.children.length > 0) {
//               //           console.log("else if")
//               //             // Recursively update child records
//               //             const updatedChildren = updateDataSourceWithParent(item.children, updatedRec);

//               //             // Store the parent's original revenue for correct percentage calculation
//               //             const extractedPropertyName =
//               //               typeof col.dataIndex === "string" && col.dataIndex.includes("(")
//               //                 ? col.dataIndex.split("(")[1].replace(")", "")
//               //                 : "";
//               //             const originalParentRevenue = parseFloat(item[extractedPropertyName]) || 0;

//               //             // Recalculate parent's total revenue as the sum of all children revenues
//               //             const totalChildRevenue = updatedChildren.reduce(
//               //                 (sum, child) => sum + parseFloat(child[col.dataIndex] || "0"),
//               //                 0
//               //             );
//               //             console.log(item)
//               //             // Calculate percentage change for the parent based on the original revenue
//               //             const parentPercentageChange = calculatePercentageChange(totalChildRevenue, originalParentRevenue);
//               //             console.log(parentPercentageChange, item[col.dataIndex], col)
//               //             // Return updated parent with recalculated total revenue and updated children
//               //             return {
//               //                 ...item,
//               //                 [col.dataIndex]: totalChildRevenue.toFixed(2),  // Update parent's revenue
//               //                 [`percentageChange_${col.dataIndex}`]: `${parentPercentageChange.toFixed(2)}%`, // Update parent's percentage change
//               //                 children: updatedChildren,  // Updated children
//               //             };
//               //         }
//               //         return item;  // Return unchanged item
//               //     });
//               // };
//               // // Recursively update the data source with the new record and adjusted hierarchy
//               // const newModifiedDataSource = updateDataSourceWithParent(modifiedDataSource, updatedRecord);
//               // // Update the state with the new data source
//               // setModifiedDataSource(newModifiedDataSource);
//           },
//           minValue: col.minValue,
//           maxValue: col.maxValue,
//           stepValue: col.stepValue,
//           showSlider: col.showSlider,
//       }),
//   })); 

//   useEffect(() => {
//     const data = prepareData().map((company) => {
//       // Check if any property in 'company' is an array (dynamic detection of children-like properties)
//       const nestedArrayKey = Object.keys(company).find(
//         (key) => Array.isArray(company[key])
//       ); 
//       let summedData = {}; 
//       // Ensure that the array exists and is not empty before trying to reduce
//       if (nestedArrayKey && company[nestedArrayKey].length > 0) {
//         summedData = company[nestedArrayKey].reduce((acc: any, item: any) => {
//           Object.keys(item).forEach((key) => {
//             // Sum only numeric fields dynamically, defaulting to 0 if undefined
//             if (typeof item[key] === "number") {
//               acc[key] = (acc[key] || 0) + (item[key] || 0);
//             }
//           });
//           return acc;
//         }, {});
//       } 
//       // Return company data with dynamically calculated sums, ensuring undefined values are handled
//       return {
//         ...company,
//         ...Object.keys(summedData).reduce((acc, key) => {
//           acc[key] = summedData[key] !== undefined ? summedData[key] : 0; // Ensure no undefined values
//           return acc;
//         }, {}),
//       };
//     });

//     setFetchedDataSource(data);
//     setModifiedDataSource(data);
//   }, []);  
//   useEffect(() => {
//     if (fetchedDataSource.length >= 1) {
//       const firstRecord = fetchedDataSource[0]; 
//       const dynamicColumns = Object.keys(firstRecord)
//         .filter((key) => key !== "children") // Exclude 'children' as it's nested data
//         .map((key) => ({
//           title: key.replace(/([A-Z])/g, " $1").trim(), // Convert camelCase to space-separated words
//           dataIndex: key,
//           key,
//           render: (value: any) => {
//             if (typeof value === "number") {
//               // Format numbers, and default undefined values to $0.00
//               return value !== undefined ? `${value.toFixed(2)}` : `$0.00`;
//             }
//             if (typeof value === "string") {
//               return value;
//             }
//             return value !== undefined ? String(value) : 'N/A'; // Handle any other data type
//           },
//         })); 
//       setColumns(dynamicColumns);
//     }
//   }, [fetchedDataSource]);
//   useEffect(() => {
//     console.log(clickedColumnName, "Clicked Col in useEffect")
//     switch(modalObject.selectedRadio) {
//       case ARRAY_RADIO[0]: { 
//         blankForecast() 
//       }
//       break;
//       case ARRAY_RADIO[1]: { 
//         // simulationUsingSlider()
//       }
//       break;
//       case ARRAY_RADIO[2]: {
//         existingForecast()
//       }
//       break;
//       case ARRAY_RADIO[3]: {}
//       break;
//       default: {}
//     }
//   }, [modalObject, clickedColumnName]);
 
//   const handleModalSubmit = (obj: any) => {
//     console.log("Popup object", obj);
//     setModalObject(obj)
//     if(obj.selectedColumn) {
//       setClickedColumnName(obj.selectedColumn)
//     }
//   };
//   const onRemoveButtonClicked = (key: string) => {
//     setColumns((prevColumns) => {
//       const filteredColumns = prevColumns.filter((col) => col.key !== key);
//       return filteredColumns;
//     });
//     setModifiedDataSource((prevDataSource) =>
//       prevDataSource.map((row) => {
//         const { [key]: _, ...rest } = row;
//         return rest;
//       })
//     );
//   };
//   // const blankForecast = () => {
//   //   // Check if modalObject and dateRange exist and are valid
//   //   if (!modalObject || !modalObject.dateRange) {
//   //     console.error('modalObject or dateRange is missing.');
//   //     return;
//   //   }

//   //   // Extract the date range
//   //   const forecastRange = modalObject.dateRange;
//   //   const years = forecastRange[1].year() - forecastRange[0].year() + 1;
    
//   //   // Array of forecast values (assuming all are zero for this example)
//   //   const forecasts = Array(years).fill(0);
    
//   //   // Create a copy of existing columns
//   //   const updatedColumns = [...columns];

//   //   // Generate forecast columns based on the date range
//   //   Array.from({ length: years }, (_, index) => {
//   //     const columnYear = forecastRange[0].year() + index;
//   //     const columnKey = `${modalObject.inputTitle}(${columnYear})`;
//   //     // Check if the column already exists
//   //     const columnExists = updatedColumns.some((existingCol) => existingCol.key === columnKey);
//   //     console.log(columnKey, columnExists, forecasts[index])

//   //     // If the column does not exist, add a new one
//   //     if (!columnExists) {
//   //       const newCol = {
//   //         key: columnKey,
//   //         forecastValue: forecasts[index], // Using forecast value at the current index
//   //         title: (
//   //           <div style={{ display: 'flex', gap: '2px', alignItems: 'center' }}>
//   //             <div style={{ display: 'flex', gap: '1px' }}>
//   //               <span>{columnKey}</span>
//   //             </div>
//   //             <Button
//   //               type="link"
//   //               icon={<MinusOutlined />}
//   //               onClick={() => onRemoveButtonClicked(columnKey)}
//   //               style={{ marginLeft: 8 }}
//   //             />
//   //           </div>
//   //         ),
//   //         dataIndex: columnKey,
//   //         editable: true,
//   //         width: '20%',
//   //       };

//   //       // Add the new column to the updated columns array
//   //       updatedColumns.push(newCol);
//   //     }
//   //   });

//   //   // Log the updated columns for debugging purposes
//   //   console.log(updatedColumns);

//   //   // Update the state with the new columns
//   //   setColumns(updatedColumns);

//   //   // Update the modifiedDataSource with new keys (if applicable)
//   //   setModifiedDataSource((prevDataSource) =>
//   //     prevDataSource.map((row) => {
//   //       // Recursively update the keys in the data source
//   //       const newRow = updateKeysRecursively(row, columnKey);
//   //       return newRow;
//   //     })
//   //   );
//   // };
//   const existingForecast = () => {
//     // Check if modalObject and dateRange exist and are valid
//     if (!modalObject || !modalObject.selectedColumn) {
//       console.error('modalObject or dateRange is missing.');
//       return;
//     }
//     const selectedColumn = modalObject.selectedColumn 
//     const updatedColumns = [...columns]; 
//     const columnKey = `${modalObject.inputTitle}(${selectedColumn})`; 
//     // Check if the column already exists
//     const columnExists = updatedColumns.some((existingCol) => existingCol.key === columnKey); 
//     // If the column does not exist, add a new one
//     if (!columnExists) {
//       const newCol = {
//         key: columnKey,
//         title: (
//           <div style={{ display: 'flex', gap: '2px', alignItems: 'center' }}>
//             <div style={{ display: 'flex', gap: '1px' }}>
//               <span>{columnKey}</span>
//             </div>
//             <Button
//               type="link"
//               icon={<MinusOutlined />}
//               onClick={() => onRemoveButtonClicked(columnKey)}
//               style={{ marginLeft: 8 }}
//             />
//           </div>
//         ),
//         dataIndex: selectedColumn,
//         editable: true,
//         width: '20%',
//       };

//       // Add the new column to the updated columns array
//       updatedColumns.push(newCol);
//     } 
//     // Log the updated columns for debugging purposes
//     console.log(updatedColumns); 
//     // Update the state with the new columns
//     setColumns(updatedColumns); 
//     // Update the modifiedDataSource with new keys (if applicable)
//     setModifiedDataSource((prevDataSource) =>
//       prevDataSource.map((row) => {
//         // Recursively update the keys in the data source
//         const newRow = 12//updateKeysRecursively(row, modalObject.inputTitle);
//         return newRow;
//       })
//     );
//   }
//   // const updateKeysRecursively = (row, prefix) => {
//   //   const newRow = { ...row }
//   //   Object.keys(row).forEach((key) => {
//   //     if (key !== "ID" && key !== "CompanyName") {
//   //       const newKey = `${prefix}(${key})`;

//   //       // If the value is an array (children), do not create a new children, just update the existing ones
//   //       if (Array.isArray(row[key])) {
//   //         // Recursively update the children
//   //         newRow[key] = row[key].map((child) => updateKeysRecursively(child, prefix));
//   //       } else if (typeof row[key] === 'object' && row[key] !== null) {
//   //         // If it's a nested object, recursively update its properties
//   //         newRow[newKey] = updateKeysRecursively(row[key], prefix);
//   //       } else {
//   //         // For other fields, update the key with the prefix (modalObject.inputTitle)
//   //         newRow[newKey] = ""//row[key];
//   //       }
//   //     }
//   //   });

//   //   return newRow;
//   // };
//   const blankForecast = () => {
//     // Check if modalObject and dateRange exist and are valid
//     if (!modalObject || !modalObject.dateRange) {
//       console.error('modalObject or dateRange is missing.');
//       return;
//     }

//     // Extract the date range
//     const forecastRange = modalObject.dateRange;
//     const years = forecastRange[1].year() - forecastRange[0].year() + 1;

//     // Array of forecast values (assuming all are zero for this example)
//     const forecasts = Array(years).fill(0);

//     // Create a copy of existing columns
//     const updatedColumns = [...columns];

//     // Generate forecast columns based on the date range
//     Array.from({ length: years }, (_, index) => {
//       const columnYear = forecastRange[0].year() + index;
//       const columnKey = `${modalObject.inputTitle}(${columnYear})`;

//       // Check if the column already exists
//       const columnExists = updatedColumns.some((existingCol) => existingCol.key === columnKey);
//       console.log(columnKey, columnExists, forecasts[index]);

//       // If the column does not exist, add a new one
//       if (!columnExists) {
//         const newCol = {
//           key: columnKey,
//           forecastValue: forecasts[index], // Using forecast value at the current index
//           title: (
//             <div style={{ display: 'flex', gap: '2px', alignItems: 'center' }}>
//               <div style={{ display: 'flex', gap: '1px' }}>
//                 <span>{columnKey}</span>
//               </div>
//               <Button
//                 type="link"
//                 icon={<MinusOutlined />}
//                 onClick={() => onRemoveButtonClicked(columnKey)}
//                 style={{ marginLeft: 8 }}
//               />
//             </div>
//           ),
//           dataIndex: columnKey,
//           editable: true,
//           width: '20%',
//         };

//         // Add the new column to the updated columns array
//         updatedColumns.push(newCol);
//       }
//     });

//     // Log the updated columns for debugging purposes
//     console.log(updatedColumns);

//     // Update the state with the new columns
//     setColumns(updatedColumns);

//     // Update the modifiedDataSource with new keys (if applicable)
//     setModifiedDataSource((prevDataSource) =>
//       prevDataSource.map((row) => {
//         // Recursively update the keys in the data source, passing each year as the prefix
//         let newRow = { ...row };
//         Array.from({ length: years }, (_, index) => {
//           const year = forecastRange[0].year() + index;
//           const columnKey = `${modalObject.inputTitle}(${year})`;
//           newRow = updateKeysRecursively(row, columnKey, year);
//         });
//         return newRow;
//       })
//     );
//   };

//   const futureForecast = () => {
//     //use the previous 2 years's data example Revenue
//   }
//   const forecastMultipleYears = (year2023: string, year2024: string, years: number): number[] => {
//     const forecasts: number[] = [];
//     const value2023 = parseFloat(year2023);
//     const value2024 = parseFloat(year2024);
//     if (isNaN(value2023) || isNaN(value2024) || value2023 === 0) {
//       return Array(years).fill(0);
//     }
//     const growthRate = (value2024 - value2023) / value2023;
//     forecasts.push(parseFloat((value2024 * (1 + growthRate)).toFixed(2)));
//     for (let i = 1; i < years; i++) {
//       const nextForecast = parseFloat((forecasts[i - 1] * (1 + growthRate)).toFixed(2));
//       forecasts.push(nextForecast);
//     }
//     return forecasts;
//   };
//   // Recursive function to update keys in the data source with the correct year-based key
//   const updateKeysRecursively = (row, prefix, year) => {
//     const newRow = { ...row };

//     Object.keys(row).forEach((key) => {
//       if (key !== "ID" && key !== "CompanyName") {
//         const newKey = `${prefix}(${key})`; // Ensure the new key reflects the columnKey format

//         // If the value is an array (children), update the children recursively
//         // if (Array.isArray(row[key])) {
//         //   newRow[key] = row[key].map((child) => updateKeysRecursively(child, prefix, year));
//         // } else if (typeof row[key] === 'object' && row[key] !== null) {
//         //   // If it's a nested object, recursively update its properties
//         //   newRow[newKey] = updateKeysRecursively(row[key], prefix, year);
//         // } else {
//         //   // For other fields, update the key with the prefix and year
//         //   newRow[newKey] = row[key] || ""; // Ensure the value isn't lost
//         // }
//       }
//     });

//     return newRow;
//   };


//   console.log(modifiedDataSource)
//   return (
//     <div>
//       <Button 
//         className="button-style" 
//         style={{ margin: "10px 10px" }}
//         onClick={() => setPopUpVisible(true)}>
//         Forecaste
//       </Button>
//       <Table
//         bordered
//         components={components}
//         className="custom-table hide-scrollbar"
//         dataSource={modifiedDataSource}
//         columns={mappedColumns as ColumnTypes}
//         pagination={{
//           total: modifiedDataSource.length,
//           position: ["bottomRight"],
//           showSizeChanger: false,
//           itemRender: (_, type, originalElement) => {
//             if (type === "prev") {
//               return <LeftOutlined />;
//             }
//             if (type === "next") {
//               return <RightOutlined />;
//             }
//             return originalElement;
//           },
//         }}
//         rowKey="ID"
//         scroll={{ x: "100%", y: 400 }} 
//       />
       
//       {
//         isPopUpVisible ?
//           <PopupModal
//             availableColumns={columns}
//             onClose={() => setPopUpVisible(false)}
//             onSubmit={handleModalSubmit}
//           /> : <></>
//       }
//     </div>
//   )
// } 

// export default Forcasting











//through abhishek bhai
import * as React from "react";
import "../../src/forcast.css"
import { Dayjs } from 'dayjs';
import { useContext, useEffect, useRef, useState, createContext } from "react";
import { SiCodeforces } from "react-icons/si";
import XLSX from 'xlsx/dist/xlsx.full.min.js';
import Papa from "papaparse"
import { data, columns, prepareData } from './../data'
import { EditableCellProps, EditableContext, Item, EditableRow, EditableCell } from './EditableCellForecast'
import {
  MinusOutlined, LeftOutlined, RightOutlined
} from "@ant-design/icons";
import {
  DatePicker,
  TableProps, Button, Table
} from "antd";
import { PopupModal, WhatIfParameterType, BlankForecastObject, ARRAY_RADIO } from "./PopUpForecast"
const { RangePicker } = DatePicker;
interface RevenueData {
  ID: any;
  key: string;
  CompanyName: string;
  Revenue2022: string;
  Revenue2023: string;
  Revenue2024: string;
  forecasts?: Array<{ key: string; forecastValue: number }>;
}
interface ForecastingProps {
  host: any;
  options1: any;
  dataView: any;
  exportDataCb: any;
  formattingSettings: any;
  target: any;
}
type ColumnTypes = Exclude<TableProps["columns"], undefined>;
const Forcasting: React.FC<ForecastingProps> = ({
}) => {
  const [columns, setColumns] = useState<any[]>([]);
  const [fetchedDataSource, setFetchedDataSource] = useState<any[]>([]);
  const [modifiedDataSource, setModifiedDataSource] = useState<any[]>([]);
  //popup related
  const [isPopUpVisible, setPopUpVisible] = useState(false);
  const [clickedColumnName, setClickedColumnName] = useState<string>("");
  const [modalObject, setModalObject] = useState<any>({})
  const components = {
    body: {
      row: EditableRow,
      cell: EditableCell,
    },
  };
  const mappedColumns = columns.map((col) => ({
    ...col,
    onCell: (record) => ({
      record,
      editable: col.editable,
      dataIndex: col.dataIndex,
      title: col.title,
      handleSave: (updatedRecord, updatedChildren) => {
      },
      minValue: col.minValue,
      maxValue: col.maxValue,
      stepValue: col.stepValue,
      showSlider: col.showSlider,
    }),
  }));
  useEffect(() => {
    const data = prepareData().map((company) => {
      // Check if any property in 'company' is an array (dynamic detection of children-like properties)
      const nestedArrayKey = Object.keys(company).find(
        (key) => Array.isArray(company[key])
      );
      let summedData = {};
      // Ensure that the array exists and is not empty before trying to reduce
      if (nestedArrayKey && company[nestedArrayKey].length > 0) {
        summedData = company[nestedArrayKey].reduce((acc: any, item: any) => {
          Object.keys(item).forEach((key) => {
            // Sum only numeric fields dynamically, defaulting to 0 if undefined
            if (typeof item[key] === "number") {
              acc[key] = (acc[key] || 0) + (item[key] || 0);
            }
          });
          return acc;
        }, {});
      }
      // Return company data with dynamically calculated sums, ensuring undefined values are handled
      return {
        ...company,
        ...Object.keys(summedData).reduce((acc, key) => {
          acc[key] = summedData[key] !== undefined ? summedData[key] : 0; // Ensure no undefined values
          return acc;
        }, {}),
      };
    });

    setFetchedDataSource(data);
    setModifiedDataSource(data);
  }, []);
  useEffect(() => {
    if (fetchedDataSource.length >= 1) {
      const firstRecord = fetchedDataSource[0];
      const dynamicColumns = Object.keys(firstRecord)
        .filter((key) => key !== "children") // Exclude 'children' as it's nested data
        .map((key) => ({
          title: key.replace(/([A-Z])/g, " $1").trim(), // Convert camelCase to space-separated words
          dataIndex: key,
          key,
          render: (value: any) => {
            if (typeof value === "number") {
              // Format numbers, and default undefined values to $0.00
              return value !== undefined ? `${value.toFixed(2)}` : `$0.00`;
            }
            if (typeof value === "string") {
              return value;
            }
            return value !== undefined ? String(value) : 'N/A'; // Handle any other data type
          },
        }));
      setColumns(dynamicColumns);
    }
  }, [fetchedDataSource]);
  useEffect(() => {
    switch (modalObject.selectedRadio) {
      case ARRAY_RADIO[0]: {
        blankForecast()
      }
        break;
      case ARRAY_RADIO[1]: {
        // futureForecast()
        futureforacstbyvicky()
      }
        break;
      case ARRAY_RADIO[2]: {
        existingForecast()
      }
        break;
      case ARRAY_RADIO[3]: { }
        break;
      default: { }
    }
  }, [modalObject, clickedColumnName]);
  const handleModalSubmit = (obj: any) => {
    setModalObject(obj)
    if (obj.selectedColumn) {
      setClickedColumnName(obj.selectedColumn)
    }
  };
  const onRemoveButtonClicked = (key: string) => {
    setColumns((prevColumns) => {
      const filteredColumns = prevColumns.filter((col) => col.key !== key);
      return filteredColumns;
    });
    setModifiedDataSource((prevDataSource) =>
      prevDataSource.map((row) => {
        const { [key]: _, ...rest } = row;
        return rest;
      })
    );
  };
  const blankForecast = () => {
    // Check if modalObject and dateRange exist and are valid
    if (!modalObject || !modalObject.dateRange) {
      return;
    }
    const forecastRange = modalObject.dateRange;
    const years = forecastRange[1].year() - forecastRange[0].year() + 1;
    const forecasts = Array(years).fill(0);
    const updatedColumns = [...columns];
    Array.from({ length: years }, (_, index) => {
      const columnYear = forecastRange[0].year() + index;
      const columnKey = `${modalObject.inputTitle}(${columnYear})`;
      const columnExists = updatedColumns.some((existingCol) => existingCol.key === columnKey);
      if (!columnExists) {
        const newCol = {
          key: columnKey,
          forecastValue: forecasts[index], // Using forecast value at the current index
          title: (
            <div style={{ display: 'flex', gap: '2px', alignItems: 'center' }}>
              <div style={{ display: 'flex', gap: '1px' }}>
                <span>{columnKey}</span>
              </div>
              <Button
                type="link"
                icon={<MinusOutlined />}
                onClick={() => onRemoveButtonClicked(columnKey)}
                style={{ marginLeft: 8 }}
              />
            </div>
          ),
          dataIndex: columnKey,
          editable: true,
          width: '20%',
        };
        updatedColumns.push(newCol);
      }
    });
    setColumns(updatedColumns);
    setModifiedDataSource((prevDataSource) =>
      prevDataSource.map((row) => {
        // Recursively update the keys in the data source
        const newRow = updateKeysRecursively1(row, modalObject.inputTitle);
        return newRow;
      })
    );
  };
  const existingForecast = () => {
    // Check if modalObject and dateRange exist and are valid
    if (!modalObject || !modalObject.selectedColumn) {
      return;
    }
    const selectedColumn = modalObject.selectedColumn
    const updatedColumns = [...columns];
    const columnKey = `${modalObject.inputTitle}(${selectedColumn})`;
    // Check if the column already exists
    const columnExists = updatedColumns.some((existingCol) => existingCol.key === columnKey);
    // If the column does not exist, add a new one
    if (!columnExists) {
      const newCol = {
        key: columnKey,
        title: (
          <div style={{ display: 'flex', gap: '2px', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: '1px' }}>
              <span>{columnKey}</span>
            </div>
            <Button
              type="link"
              icon={<MinusOutlined />}
              onClick={() => onRemoveButtonClicked(columnKey)}
              style={{ marginLeft: 8 }}
            />
          </div>
        ),
        dataIndex: selectedColumn,
        editable: true,
        width: '20%',
      };

      // Add the new column to the updated columns array
      updatedColumns.push(newCol);
    }
    setColumns(updatedColumns);
    // Update the modifiedDataSource with new keys (if applicable)
    setModifiedDataSource((prevDataSource) =>
      prevDataSource.map((row) => {
        // Recursively update the keys in the data source
        const newRow = updateKeysRecursively1(row, modalObject.inputTitle);
        return newRow;
      })
    );
  }

  const forecastMultipleYears = (year2023: string, year2022: string, years: number): number[] => {
    const forecasts: number[] = [];
    const value2023 = parseFloat(year2023);
    const value2022 = parseFloat(year2022);

    if (isNaN(value2023) || isNaN(value2022) || value2023 === 0) {
        return Array(years).fill(0); // Return an array filled with zero if data is invalid
    }

    const growthRate = (value2023 - value2022) / value2022; // Calculate growth rate
    forecasts.push(parseFloat((value2023 * (1 + growthRate)).toFixed(2))); // First forecast year

    // Calculate subsequent forecasts
    for (let i = 1; i < years; i++) {
        const nextForecast = parseFloat((forecasts[i - 1] * (1 + growthRate)).toFixed(2));
        forecasts.push(nextForecast); // Push next forecast to array
    }
    
    return forecasts; // Return the forecast array
};

const futureforacstbyvicky = () => {
    // Check if modalObject and dateRange exist and are valid
    if (!modalObject || !modalObject.dateRange) {
        return;
    }

    const forecastRange = modalObject.dateRange;
    const years = forecastRange[1].year() - forecastRange[0].year() + 1; // Number of years to forecast
    const updatedColumns = [...columns];

    // Create forecast columns
    Array.from({ length: years }, (_, index) => {
        const columnYear = forecastRange[0].year() + index; // Get year for each forecast
        const columnKey = `${modalObject.inputTitle}(${columnYear})`; // Create the dynamic column name
        
        // Check if column exists already
        const columnExists = updatedColumns.some((existingCol) => existingCol.key === columnKey);
        
        if (!columnExists) {
            const newCol = {
                key: columnKey,
                title: (
                    <div style={{ display: 'flex', gap: '2px', alignItems: 'center' }}>
                        <span>{columnKey}</span>
                        <Button
                            type="link"
                            icon={<MinusOutlined />}
                            onClick={() => onRemoveButtonClicked(columnKey)}
                            style={{ marginLeft: 8 }}
                        />
                    </div>
                ),
                dataIndex: columnKey,
                editable: true,
                width: '20%',
            };
            updatedColumns.push(newCol);
        }
    });

    setColumns(updatedColumns); // Set updated columns

    // Update data source by forecasting values and adding new properties for each year
    setModifiedDataSource((prevDataSource) =>
        prevDataSource.map((row) => updateKeysRecursively(row, modalObject.inputTitle, years))
    );
};

const updateKeysRecursively = (row, prefix, years) => {
    const newRow = { ...row };

    // Find last two numerical revenue values
    const revenueKeys = Object.keys(row).filter(key => key.includes('Revenue') && typeof row[key] === 'number');

    if (revenueKeys.length >= 2) {
        const lastRevenue = row[revenueKeys[0]]; // Latest revenue
        const secondLastRevenue = row[revenueKeys[1]]; // Previous revenue

        // Forecast values based on the last two revenue entries
        const forecastValues = forecastMultipleYears(secondLastRevenue.toString(), lastRevenue.toString(), years);

        // Add forecast values to the new row based on the column keys (years)
        forecastValues.forEach((forecast, index) => {
            const columnKey = `${prefix}(${modalObject.dateRange[0].year() + index})`;
            newRow[columnKey] = forecast; // Assign the forecast value to the columnKey
        });
    }

    // Recursively update keys for children
    Object.keys(row).forEach((key) => {
        if (key !== "ID" && key !== "CompanyName") {
            const newKey = `${prefix}(${key})`;

            if (Array.isArray(row[key])) {
                // Recursively update the children
                newRow[key] = row[key].map((child) => updateKeysRecursively(child, prefix, years));
            } else if (typeof row[key] === 'object' && row[key] !== null) {
                // If it's a nested object, recursively update its properties
                newRow[newKey] = updateKeysRecursively(row[key], prefix, years);
            } else {
                // For other fields, update the key with the prefix
                newRow[newKey] = row[key];
            }
        }
    });

    return newRow;
};

// Console log to check modified data source
console.log(modifiedDataSource, "ModifiedDataSource");

 
    const updateKeysRecursively1 = (row, prefix) => {
      const newRow = { ...row };
  
      Object.keys(row).forEach((key) => {
        if (key !== "ID" && key !== "CompanyName") {
          const newKey = `${prefix}(${key})`;
  
          // If the value is an array (children), do not create a new children, just update the existing ones
          if (Array.isArray(row[key])) {
            // Recursively update the children
            newRow[key] = row[key].map((child) => updateKeysRecursively1(child, prefix));
          } else if (typeof row[key] === 'object' && row[key] !== null) {
            // If it's a nested object, recursively update its properties
            newRow[newKey] = updateKeysRecursively1(row[key], prefix);
          } else {
            // For other fields, update the key with the prefix (modalObject.inputTitle)
            newRow[newKey] = ""//row[key];
          }
        }
      });
  
      return newRow;
    };
  
  const flattenHierarchy = (row, parentId = '', result = []) => {
    // Create a copy of the row to avoid mutating the original object
    const currentRow = { ...row };
    delete currentRow.children; // Remove the children property for the current row

    // Define the important fields to check for values
    const importantFields = ['Revenue', 'Revenue2022'];

    // Check if important fields have values, skip if all are empty
    const hasImportantValues = importantFields.some(field => row[field] !== undefined && row[field] !== '');

    if (!hasImportantValues) {
      // Skip this row if none of the important fields are populated
      return result;
    }

    if (parentId) {
      currentRow.ID = `${parentId}.${currentRow.ID}`; // Append parent ID to create hierarchical structure
    }

    result.push(currentRow); // Add the current row to the result array

    // If there are children, recursively process each child
    if (row.children && Array.isArray(row.children)) {
      row.children.forEach((child) => {
        flattenHierarchy(child, currentRow.ID, result); // Recursively flatten child rows
      });
    }

    return result;
  };
  console.log(modifiedDataSource, "  console.log(modifiedDataSource)")
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Button
          className="button-style"
          style={{ margin: "10px 10px" }}
          onClick={() => setPopUpVisible(true)}>
          Forecaste
        </Button>
      </div>
      <Table
        bordered
        components={components}
        className="custom-table hide-scrollbar"
        dataSource={modifiedDataSource}
        columns={mappedColumns as ColumnTypes}
        pagination={{
          total: modifiedDataSource.length,
          position: ["bottomRight"],
          showSizeChanger: false,
          itemRender: (_, type, originalElement) => {
            if (type === "prev") {
              return <LeftOutlined />;
            }
            if (type === "next") {
              return <RightOutlined />;
            }
            return originalElement;
          },
        }}
        rowKey="ID"
        scroll={{ x: "max-content", y: 400 }}
      />
      {
        isPopUpVisible ?
          <PopupModal
            availableColumns={columns}
            onClose={() => setPopUpVisible(false)}
            onSubmit={handleModalSubmit}
          /> : <></>
      }
    </div>
  )
}

export default Forcasting








